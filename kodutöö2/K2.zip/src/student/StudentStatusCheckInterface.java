package student;

/**
 * Created by Jaanus on 14.09.16.
 */
public interface StudentStatusCheckInterface {
    boolean isStudent(String identificationCode, String schoolIdentifier);
}

package compressor;

/**
 * Created by Jaanus on 28.10.16.
 */
public interface Compressor {
    String compress(String stringToCompress);
}

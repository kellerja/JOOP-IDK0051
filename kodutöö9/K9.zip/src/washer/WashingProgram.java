package washer;

/**
 * Created by Jaanus on 20.11.16.
 */
public interface WashingProgram {
    void startCycle(DishWasher washingMachine);
    void printDuration();
}

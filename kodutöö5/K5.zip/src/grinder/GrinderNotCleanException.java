package grinder;

/**
 * Created by Jaanus on 5.10.16.
 */
public class GrinderNotCleanException extends RuntimeException {

    public GrinderNotCleanException(String message) {
        super(message);
    }
}

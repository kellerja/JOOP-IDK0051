package grinder;

/**
 * Created by Jaanus on 7.10.16.
 */
public class FlavourNotAvailableException extends RuntimeException {
    public FlavourNotAvailableException(String message) {
        super(message);
    }
}

package seat;

/**
 * Created by Jaanus on 19.10.16.
 */
public class SeatLoweringLimitExceeded extends RuntimeException {
}
